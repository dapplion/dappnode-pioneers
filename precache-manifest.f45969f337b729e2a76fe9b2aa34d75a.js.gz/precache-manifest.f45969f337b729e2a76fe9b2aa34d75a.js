self.__precacheManifest = [
  {
    "revision": "db33a17a479d0016a4c70515150e1e49",
    "url": "/dappnode-pioneers/static/media/dappnode-logo.db33a17a.png"
  },
  {
    "revision": "d34d05025f1add550074",
    "url": "/dappnode-pioneers/static/js/runtime~main.d34d0502.js"
  },
  {
    "revision": "6aafefe9e94ac231eb67",
    "url": "/dappnode-pioneers/static/js/main.6aafefe9.chunk.js"
  },
  {
    "revision": "e7f7481c80bfcd8e0671",
    "url": "/dappnode-pioneers/static/js/2.e7f7481c.chunk.js"
  },
  {
    "revision": "6aafefe9e94ac231eb67",
    "url": "/dappnode-pioneers/static/css/main.03f0a84b.chunk.css"
  },
  {
    "revision": "e7f7481c80bfcd8e0671",
    "url": "/dappnode-pioneers/static/css/2.0391fb14.chunk.css"
  },
  {
    "revision": "51cab123510de08ff6b73b13be72949d",
    "url": "/dappnode-pioneers/index.html"
  }
];