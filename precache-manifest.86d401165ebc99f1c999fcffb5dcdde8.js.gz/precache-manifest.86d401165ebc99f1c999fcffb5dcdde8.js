self.__precacheManifest = [
  {
    "revision": "db33a17a479d0016a4c70515150e1e49",
    "url": "./static/media/dappnode-logo.db33a17a.png"
  },
  {
    "revision": "9eb600ee07a27cdad64f",
    "url": "./static/js/runtime~main.9eb600ee.js"
  },
  {
    "revision": "e877c191c496f90361c9",
    "url": "./static/js/main.e877c191.chunk.js"
  },
  {
    "revision": "e7f7481c80bfcd8e0671",
    "url": "./static/js/2.e7f7481c.chunk.js"
  },
  {
    "revision": "e877c191c496f90361c9",
    "url": "./static/css/main.03f0a84b.chunk.css"
  },
  {
    "revision": "e7f7481c80bfcd8e0671",
    "url": "./static/css/2.0391fb14.chunk.css"
  },
  {
    "revision": "cdad6411d8ce7548a772337e43125adb",
    "url": "./index.html"
  }
];