self.__precacheManifest = [
  {
    "revision": "db33a17a479d0016a4c70515150e1e49",
    "url": "/dappnode-pioneers/static/media/dappnode-logo.db33a17a.png"
  },
  {
    "revision": "d34d05025f1add550074",
    "url": "/dappnode-pioneers/static/js/runtime~main.d34d0502.js"
  },
  {
    "revision": "f98cb085ac83ac61556d",
    "url": "/dappnode-pioneers/static/js/main.f98cb085.chunk.js"
  },
  {
    "revision": "5bf9b2cda7c63b962686",
    "url": "/dappnode-pioneers/static/js/2.5bf9b2cd.chunk.js"
  },
  {
    "revision": "f98cb085ac83ac61556d",
    "url": "/dappnode-pioneers/static/css/main.2a03835a.chunk.css"
  },
  {
    "revision": "477e6d4a6e488f8f841ed754eec73974",
    "url": "/dappnode-pioneers/index.html"
  }
];